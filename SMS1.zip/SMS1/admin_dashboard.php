<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> admin dashboard</title>
	<style>
		#header{
			font-size: 40px;
			color: orange;
			background-color: darkred;
			position: relative;
			overflow: auto;
		}
		#right_side{
			width: 800px;
			height: 70vh;
			border: 2px solid red;
			background-color:rosybrown ;
			position:absolute;
			top: 130px;
			right: 300px;

		}
		#left_side{
			height: 400px;
			width: 10%;
			background-color: aqua;
			color: blue;
			font-size: 50px;
		}
		#main{
			font-size: 20px;
			color: darkred;
		}
		#teacher{
			border: 2px solid black;
			/*width: 80px;
			left: 17px;*/
			/*color: green;*/
			padding-left: 2px;
			text-align: center;
			width: 200px;
		}
	</style>
	<?php
session_start();
 $connection=mysqli_connect("localhost","root","");
$db= mysqli_select_db($connection,"sms1");
	?>
</head>
<body>
<div id="header">
	<center>student management system<br>
		<strong>Email:<?php echo$_SESSION['email'];?>
	Name:Admin
<a href="logout.php">Logout</a></center>
</div>
<span id="main"><marquee>Note:this portal open  till april 12pm </marquee></span>
<div id="left_side">
	<form action="" method="post">
		<table>
			<tr>
				<td>
					<input type="submit" name="search_student" value="Search_Student">
				</td>
			</tr>
				<tr>
				<td>
					<input type="submit" name="edit_student" value="Edit_Student">
				</td>
			</tr>
			<tr>
			<td>
					<input type="submit" name="add_new_student" value="Add New_Student">
				</td>
			</tr>

			<tr>
			<td>
				<input type="submit" name="Delete_student" value="Delete_Student">
				</td>
			</tr>

			<tr>
				<td>
					<input type="submit" name="show_teacher" value="Show_Teacher">
				</td>
			</tr>
		</table>
	</form>
</div>
<div id="right_side">
	<div id="demo">
		<?php
		if(isset($_POST['search_student'])){
			?>
			<center>
			<form action="" method="post" >
				Enter roll no:
				<input type="text" name="roll_no">
				<input type="submit" name="search_by_roll_no_for_search">
			</form>
		</center>
		<?php
		}
		if (isset($_POST['search_by_roll_no_for_search'])) 
		{
			$query ="select * from student where roll_no='$_POST[roll_no]'";
	        $query_run= mysqli_query($connection,$query);
	        while($row =mysqli_fetch_assoc($query_run)){
		
		?>
		<table>
			<tr>
				<td><b>Roll no:</b></td>
			
			<td>
				<input type="text" value="<?php echo $row['roll_no']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>Name:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['name']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>father_name:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['father_name']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>class:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['class']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>mobile:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['mobile']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>email:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['email']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>password:</b></td>
			
			<td>
				<input type="text" name="" value="<?php echo $row['password']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>Remark:</b></td>
			
			<td>
				<textarea cols="40" rows="3"disabled><?php echo $row['remark'];?></textarea>
			</td>
		</tr>
		</table>
		</div><?php
	}
}
?>
<?php
		if(isset($_POST['edit_student'])){
			?>
			<center>
			<form action="" method="post" >
				Enter roll no:
				<input type="text" name="roll_no">
				<input type="submit" name="search_by_roll_no_for_edit">
			</form>
		</center>
		<?php
		}
		if (isset($_POST['search_by_roll_no_for_edit'])) 
		{
			$query ="select * from student where roll_no='$_POST[roll_no]'";
	        $query_run= mysqli_query($connection,$query);
	        while($row =mysqli_fetch_assoc($query_run)){
		
		?>
		<form action="admin_edit_student.php" method="post">
			<table>
			<tr>
				<td><b>Roll no:</b></td>
			
			<td>
				<input type="text" name="roll_no" value="<?php echo $row['roll_no']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>Name:</b></td>
			
			<td>
				<input type="text" name="name" value="<?php echo $row['name']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>father_name:</b></td>
			
			<td>
				<input type="text" name="father_name" value="<?php echo $row['father_name']; ?>">
			</td>
		</tr>
		<tr>
				<td><b>class:</b></td>
			
			<td>
				<input type="text" name="class" value="<?php echo $row['class']; ?>">
			</td>
		</tr>
		<tr>
				<td><b>mobile:</b></td>
			
			<td>
				<input type="text" name="mobile" value="<?php echo $row['mobile']; ?>">
			</td>
		</tr>
		<tr>
				<td><b>email:</b></td>
			
			<td>
				<input type="text" name="email" value="<?php echo $row['email']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>password:</b></td>
			
			<td>
				<input type="text" name="password" value="<?php echo $row['password']; ?>"disabled>
			</td>
		</tr>
		<tr>
				<td><b>Remark:</b></td>
			
			<td>
				<textarea cols="40" rows="3"disabled name="remark"><?php echo $row['remark'];?></textarea>
			</td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="edit" value="save"> </td>
		</tr>
	</table>
		</form>
	</div>
<?php

}
}


?>
<?php
if(isset($_POST['add_new_student'])){
	?>
	<center><h4>Fill the given details</h4></center>
	<form action="add_student.php" method="post">
		<table>
			<tr>
				<td>Roll no:</td>
				<td><input type="text" name="roll_no" required></td>
			</tr>
			<tr>
				<td>Name:</td>
				<td><input type="text" name="name" required></td>
			</tr>
			<tr>
				<td>father_name:</td>
				<td><input type="text" name="father_name" required></td>
			</tr>
			<tr>
				<td>Class:</td>
				<td><input type="text" name="class" required></td>
			</tr>
			<tr>
				<td>mobile:</td>
				<td><input type="text" name="mobile" required></td>
			</tr>
			<tr>
				<td>email:</td>
				<td><input type="text" name="email" required></td>
			</tr>
			<tr>
				<td>password:</td>
				<td><input type="text" name="password" required></td>
			</tr>
			
			<tr>
				<td>Remark:</td>
				<td><textarea   rols="15" cols="35" name="remark" required></textarea></td>
			</tr>
			<tr>
			<td></td>
			<td><input type="submit" name="add" value="Add student"> </td>
		</tr>

		</table>
	</form>
	<?php
}
?>
<?php
if(isset($_POST['Delete_student'])){
?>
<center>
	<form action="delete_student.php" method="post">
	Roll no:	<input type="text" name="roll_no">
	<input type="submit" name="search_by_roll_no_for_delete" value=" delete student">
	</form>
</center>
<?php
}
?>

<?php
if (isset($_POST['show_teacher'])) {
?>
<center>
	<h2>Teacher Details</h2>
	<table>
		<tr>
			<td id="teacher"><b>ID</b></td>
			<td id="teacher"><b>Name</b></td>
			<td id="teacher"><b>Mobile</b></td>
			<td id="teacher"><b>Course</b></td>
			<td id="teacher"><b>View Details</b></td>

		</tr>
	</table>
</center>
<?php
$connection=mysqli_connect("localhost","root","");
     $db= mysqli_select_db($connection,"sms1");
     $query="select * from teacher";
     $query_run= mysqli_query($connection,$query);
        while($row =mysqli_fetch_assoc($query_run)){
     	 ?>
     	 <center>
     		<table style="border-collapse:collapse;border: 1px,solid ,red;">
     			<tr>
     				<td id="teacher"><?php echo $row['t_id']; ?></td>
     				<td id="teacher"> <?php echo $row['name']; ?></td>
     				<td id="teacher"> <?php echo $row['mobile']; ?></td>
     				<td id="teacher"> <?php echo $row['courses']; ?></td>
     				<td id="teacher"> <a href="#">View details</a></td>
     			</tr>
     		</table>
     	  </center>
     	  <?php
       }
    }
    ?>
	</div>
</div>
</body>
</html>