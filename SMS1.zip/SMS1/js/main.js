
    $('.man-0').owlCarousel({
        loop: true,
        margin: 10,
        nav: false, 
        dots:false, 
        autoplay:1000,
        responsive: {
           1000: {
                items: 1
            }
        }
    });

 



