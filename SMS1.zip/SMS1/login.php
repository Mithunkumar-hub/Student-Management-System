<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>login page</title>
	<link  rel="stylesheet" type="text/css" href="style.css">
</head>
<body class="login">
	<center>
		<h3>student management system</h3>
		<form action="" method="post">
			<input type="submit" name="admin_login" value="Admin Login">
			<input type="submit" name="student_login" value="Student Login">
		</form>
		<?php
		if(isset($_POST['admin_login'])){
			header("Location:admin_login.php");
		}
		if(isset($_POST['student_login'])){
			header("Location:student_login.php");
		}


		?>
	</center>

</body>
</html>