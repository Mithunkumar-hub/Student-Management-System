<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>student page</title>
<style type="text/css">
	body{
		background-color: hotpink;
	}
	h3{
		font-size:50px ;
	}
	table{
		font-size: 30px;
background-color: peru; 
	}
	.sub{
        font-size: 20px;
        background-color: chartreuse;
        border-radius: 5px;
        cursor: pointer;
	}
</style>
</head>
<body>
	<center>
		<h3>Student Login Page</h3>
		<form action="" method="post">
			<table>
		<tr><td>Email	<input type="text" name="email" required></td>

		<td>password	<input type="password" name="password" required="help"></td></tr>
			</table>
			<input type="submit" name="submit" class="sub">
		
		
		</form>
		<?php
		if(isset($_POST['submit'])){
     $connection=mysqli_connect("localhost","root","");
	$db= mysqli_select_db($connection,"sms1");
	$query ="select * from student where email='$_POST[email]'";
	$query_run= mysqli_query($connection,$query);
	      
	while($row =mysqli_fetch_assoc($query_run)){
	if($row['email']== $_POST['email']){
		if($row['password']==$_POST['password']){
			header("Location: student_dashboard.php");
		}
		else{
			echo "worng password";
		}
	}
		else{
			echo "wrong email id";
		}
	}

	}

		?>
		
	</center>

</body>
</html>