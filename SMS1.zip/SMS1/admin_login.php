<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>admin page</title>
	<style type="text/css">
		body{
			background-color:gainsboro;
		}
		h3{
			font-size: 50px;
		}
		form{
			font-size: 30px;
		}
	</style>
</head>
<body>
	<center>
		<h3>Admin Login page</h3>
		<form action="" method="post">

		Email	<input type="text" name="email" required><br>
		password	<input type="password" name="password" required="help"><br>
			<input type="submit" name="submit">
		</form>
		<?php
		session_start();
		if(isset($_POST['submit'])){
     $connection=mysqli_connect("localhost","root","");
	$db= mysqli_select_db($connection,"sms1");
	$query ="select * from login where email='$_POST[email]'";
	$query_run= mysqli_query($connection,$query);
	      
	while($row =mysqli_fetch_assoc($query_run)){
	if($row['email']== $_POST['email']){
		if($row['password']==$_POST['password']){
			$_SESSION['email']=$row['email'];
			$_SESSION['password']=$row['password'];
			header("Location: admin_dashboard.php");
		}
		else{
			echo "worng password";
		}
	}
		else{
			echo "wrong email id";
		}
	}

	}

		?>
		
	</center>

</body>
</html>