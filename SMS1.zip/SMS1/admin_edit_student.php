<?php
 $connection=mysqli_connect("localhost","root","");
$db= mysqli_select_db($connection,"sms1");
$query ="update student set name = '$_POST[name]' , father_name ='$_POST[father_name]',class =$_POST[class], mobile =$_POST[mobile],email ='$_POST [email]',password='$_POST[password]',remark='$_POST[remark]' where roll_no = $_POST[roll_no]";
	        $query_run= mysqli_query($connection,$query);


?>
<script>
	alert("details edited successfullly")
	window.location.herf="admin_dashboard.php";
	    </script