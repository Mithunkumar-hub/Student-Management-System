<?php
$connection=mysqli_connect("localhost","root","");
$db= mysqli_select_db($connection,"sms1");
$query ="insert into student values('',$_POST[roll_no],'$_POST[name]','$_POST[father_name]',$_POST[class],$_POST[mobile],'$_POST[email]','$_POST[password]','$_POST[remark]')";

 $query_run= mysqli_query($connection,$query);


?>
<script>
	alert("student added successfullly")
	window.location.herf="admin_dashboard.php";
	    </script>
?>