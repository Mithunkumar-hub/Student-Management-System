<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>student dashboard</title>
</head>
<body>
<h1>thank you for visit</h1>
</body>
</html>